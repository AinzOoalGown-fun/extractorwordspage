function extractWords() {
  const elements = document.getElementsByTagName("b");
  const extractedWords = [];

  for (let i = 0; i < elements.length; i++) {
    extractedWords.push(elements[i].textContent);
  }

  chrome.runtime.sendMessage({ text: extractedWords }, function(response) {
    if (response.success) {
      console.log("Les mots en gras ont été extraits avec succès !");
    } else {
      console.error("Une erreur s'est produite lors de l'extraction des mots en gras.");
    }
  });
}

extractWords();