chrome.browserAction.onClicked.addListener(async (tab) => {
  const [tabInfo] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tabInfo.id },
    files: ["content.js"]
  }, () => {
    if (chrome.runtime.lastError) {
      console.error("Une erreur s'est produite lors de l'exécution du script de contenu : ", chrome.runtime.lastError);
    }
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.text) {
    const extractedWords = request.text;
    const extractedText = extractedWords.join("\n");
    const blob = new Blob([extractedText], { type: "text/plain" });

    chrome.downloads.download({
      url: URL.createObjectURL(blob),
      filename: "extraitmots.txt",
      saveAs: true
    }, (downloadId) => {
      if (downloadId) {
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false });
      }
    });
  }

  return true;
});